<?php
include 'conexao.php';
include 'cadastro.php';
include 'contato.php';
include 'orcamento.php';






?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF8">
        <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MSL-Climatização</title>
    </head>
    <main><h1>Bem vindo á MSL Climatização!</h1><br></main>
</html>