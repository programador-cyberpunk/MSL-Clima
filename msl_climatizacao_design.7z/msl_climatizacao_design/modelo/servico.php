<?php
/*
aqui é onde eu vai os tipos de serviço, e o preço de cada um,onde os preços e 
serviços ficam salvos no banco de dados, paralelo a tabela de clientes e tabela contatos,
*/
class Servico {
    //qual a diferença entre protected e private???

    protected $nome;
    protected $preco;

    public function __construct($nome, $preco) {
        $this->nome = $nome;
        $this->preco = $preco;
    }
   public function getNome(){
    return $this->nome;
    } 
   public function getPreco(){
    return $this->nome;
   }
}
class ServicoOrcamento extends Servico {
    private $taxaTrampo; //me faltou termo melhor

    public function __construct($nome, $preco, $taxaTrampo){
       // o que é parent???
        parent::__construct($nome, $preco,);
        $this->taxaTrampo = $taxaTrampo;
    }
    public function getPreco(){
        return $this->preco + $this->taxaTrampo;
    }
}

$precoIsnpecao = new preco("Manutenção", 65);
$taxaTrampo = new taxaTrampo ("Orçamento", 50);






?>